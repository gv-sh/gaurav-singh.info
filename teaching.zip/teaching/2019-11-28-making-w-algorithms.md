---
tags: post
title: Making with Algorithms
showTitle: true
attribution: Alongwith students
date: 2019-11-28
deck: Photos
cover: /assets/images/2019/mwa_1.jpg
layout: post.njk
description: Recent technological developments in neural networks, computer vision and blockchains are radically transforming the digital landscape around us. Through this course, we explored the modern role of designer working with such technologies through the idea of algorithmic-driven design; and use algorithms as a material to design with.
showFurther: true
permalink: /teaching/making-with-algorithms/
--- 

Recent technological developments in neural networks, computer vision and blockchains are radically transforming the digital landscape around us. Through this course, we explored the modern role of designer working with such technologies through the idea of algorithmic-driven design; and use algorithms as a material to design with.

This note features student work.
 
<img src="/assets/images/2019/mwa_1.jpg"/>

<img src="/assets/images/2019/mwa_2.jpg"/>

<img src="/assets/images/2019/mwa_3.jpg"/>

<img src="/assets/images/2019/mwa_4.jpg"/>

<img src="/assets/images/2019/mwa_5.jpg"/>

<img src="/assets/images/2019/mwa_6.jpg"/>

<img src="/assets/images/2019/mwa_7.jpg"/>

<img src="/assets/images/2019/mwa_8.jpg"/>

<img src="/assets/images/2019/mwa_9.jpg"/>

<img src="/assets/images/2019/mwa_10.jpg"/>

<img src="/assets/images/2019/mwa_11.jpg"/>

<img src="/assets/images/2019/mwa_12.jpg"/>

<img src="/assets/images/2019/mwa_13.jpg"/>

<img src="/assets/images/2019/mwa_14.jpg"/>

<img src="/assets/images/2019/mwa_15.jpg"/>

<img src="/assets/images/2019/mwa_16.jpg"/>

<img src="/assets/images/2019/mwa_17.jpg"/>

<img src="/assets/images/2019/mwa_18.jpg"/>

<img src="/assets/images/2019/mwa_19.jpg"/>

<img src="/assets/images/2019/mwa_20.jpg"/>

<img src="/assets/images/2019/mwa_21.jpg"/>

<img src="/assets/images/2019/mwa_22.jpg"/>

<img src="/assets/images/2019/mwa_23.jpg"/>

<img src="/assets/images/2019/mwa_24.jpg"/>

<img src="/assets/images/2019/mwa_25.jpg"/>

<img src="/assets/images/2019/mwa_26.jpg"/>

<img src="/assets/images/2019/mwa_27.jpg"/>

<img src="/assets/images/2019/mwa_29.jpg"/>

<img src="/assets/images/2019/mwa_30.jpg"/>
