---
tags: post
title: Glider Gun
showTitle: true
date: 2022-09-25
deck: Workshop
description: Participants in this workshop had the option to work with their preferred programming languages or use P5.JS if they were new to programming. The workshop's main objective was to simulate cellular automata and analyse the complex behaviour it exhibits when given simple rules. They studied abstract computing models with practical uses in computer science, theoretical biology, and microstructures, like cellular automata and Turing machines. This workshop was appropriate for anyone curious about complex emergent behaviour, creative coding, and mathematics.
layout: post.njk
permalink: /teaching/glider-gun/
--- 

Participants in this workshop had the option to work with their preferred programming languages or use P5.JS if they were new to programming. The workshop's main objective was to simulate cellular automata and analyse the complex behaviour it exhibits when given simple rules. They studied abstract computing models with practical uses in computer science, theoretical biology, and microstructures, like cellular automata and Turing machines. This workshop was appropriate for anyone curious about complex emergent behaviour, creative coding, and mathematics.

